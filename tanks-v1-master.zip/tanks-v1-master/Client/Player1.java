import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ele here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player1 extends Actor
{
    /**
     * Act - do whatever the Ele wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Player1(){
    
    }
    
    public void act() 
    {
        if(Receiver.xy.id != 0){
            move();
             if("space".equals(Greenfoot.getKey()))
           {
               fire();
               
            }
        }else{
           int y = Receiver.xy.y;
           int x = Receiver.xy.x;
        
           setLocation(x,y);
        }
        
    }
    
    public void move(){
        int x = getX();
        int y = getY();
        if(Greenfoot.isKeyDown("W")&&canMoveUp()) y -= 2;
        if(Greenfoot.isKeyDown("S")&&canMoveDown()) y += 2;
        if(Greenfoot.isKeyDown("A")&&canMoveLeft()) x -= 2;
        if(Greenfoot.isKeyDown("D")&&canMoveRight()) x += 2;
        
        setLocation(x,y);
        
     //   Sender.sendData(x,y);
        
    }
     /**
     * Fire Bullets
     */
    public void fire()
    {
       Bullets bullet= new Bullets();
       getWorld().addObject(bullet,getX(),getY());
       bullet.move(10);
       
    }
    
        public boolean canMoveLeft()
    {
         boolean canMoveLeft=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
        if(getOneObjectAtOffset(imgWidth/-2-2, imgHeight/-2, Player2.class)!=null||
        getOneObjectAtOffset(imgWidth/-2-2, imgHeight/2-1, Player2.class)!=null)
        {
           canMoveLeft=false;
        }
        return canMoveLeft;
        
    }
     public boolean canMoveRight()
    {
       boolean canMoveRight=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
        if(getOneObjectAtOffset(imgWidth/2+2, imgHeight/-2, Player2.class)!=null||
        getOneObjectAtOffset(imgWidth/2+2, imgHeight/2-1, Player2.class)!=null)
        {
           canMoveRight=false;
        }
        return canMoveRight;
    }
    
    public boolean canMoveDown()
    {
       boolean canMoveDown=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
         if(getOneObjectAtOffset(imgWidth/-2, imgHeight/2, Player2.class)!=null||
        getOneObjectAtOffset(imgWidth/2, imgHeight/2, Player2.class)!=null)
        {
          canMoveDown=false;
        }
        return canMoveDown;
    }
     public boolean canMoveUp()
     {
       boolean canMoveUp=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
         if(getOneObjectAtOffset(imgWidth/-2, imgHeight/-2, Player2.class)!=null||
        getOneObjectAtOffset(imgWidth/2, imgHeight/-2, Player2.class)!=null)
        {
          canMoveUp=false;
        }
        return canMoveUp;
    }
    
    
}
