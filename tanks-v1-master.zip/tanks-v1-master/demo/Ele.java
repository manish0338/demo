import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ele here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ele extends Actor
{
    /**
     * Act - do whatever the Ele wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    boolean owner = true;
    
    private final int GRAVITY=1;
    private int velocity;
    
    public Ele(){
        if(owner==true){
            
        }
        velocity=4;
        
       // try{
       // Thread t = new Client();
       // t.start();}catch(Exception e){e.printStackTrace();
      //  }
    }
    
    public void act() 
    {
        if(owner==true){
            move();
        }else{
         //  int y = Client.y;
           //int x = Client.x;
        
          // setLocation(x,y);
        }
        //velocity=0;
        //fall();
        if(Greenfoot.isKeyDown("j")&&isOnSolidGround())
        {
            jump();
        }
        
    }
    
    public void move(){
        int x = getX();
        int y = getY();
        
        if(Greenfoot.isKeyDown("W")&&canMoveUp()) y -= 2;
        if(Greenfoot.isKeyDown("S")&&canMoveDown()) y += 2;
        if(Greenfoot.isKeyDown("A")&&canMoveLeft()) x -= 2;
        if(Greenfoot.isKeyDown("D")&&canMoveRight()) x += 2;
      
        
        setLocation(x,y);
        
        Sender.sendData(x,y);
        
    }
    public void fall()
    {
        setLocation(getX(), getY()+velocity);
        if(isOnSolidGround())
       { velocity=0;
           while(isOnSolidGround()){
               setLocation(getX(), getY()-1);
            }
             setLocation(getX(), getY()+1);
        
        }
        else if(velocity<0&&didBumpHead())
       { velocity=0;
        while(didBumpHead()){
               setLocation(getX(), getY()+1);
            }
            // setLocation(getX(), getY()+1);
            }
        else
        velocity+=GRAVITY;
    }
    public void jump()
    {
        velocity=-20;
    }
    
    public boolean isOnSolidGround()
    {
        boolean isOnGround=false;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
       if( getY()>getWorld().getHeight()-50)
       {
           isOnGround=true;
        }
        if(getOneObjectAtOffset(imgWidth/-2, imgHeight/2, Bear.class)!=null||
        getOneObjectAtOffset(imgWidth/2, imgHeight/2, Bear.class)!=null)
        {
           isOnGround=true;
        }
        
        
        return isOnGround;
    }
    
    public boolean didBumpHead(){
        boolean bumpedHead=false;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
        if(getOneObjectAtOffset(imgWidth/-2, imgHeight/-2, Bear.class)!=null||
        getOneObjectAtOffset(imgWidth/2, imgHeight/-2, Bear.class)!=null)
        {
           bumpedHead=true;
        }
        return bumpedHead;
    }
    
    public boolean canMoveLeft()
    {
         boolean canMoveLeft=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
        if(getOneObjectAtOffset(imgWidth/-2-2, imgHeight/-2, Bear.class)!=null||
        getOneObjectAtOffset(imgWidth/-2-2, imgHeight/2-1, Bear.class)!=null)
        {
           canMoveLeft=false;
        }
        return canMoveLeft;
        
    }
     public boolean canMoveRight()
    {
       boolean canMoveRight=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
        if(getOneObjectAtOffset(imgWidth/2+2, imgHeight/-2, Bear.class)!=null||
        getOneObjectAtOffset(imgWidth/2+2, imgHeight/2-1, Bear.class)!=null)
        {
           canMoveRight=false;
        }
        return canMoveRight;
    }
    
    public boolean canMoveDown()
    {
       boolean canMoveDown=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
         if(getOneObjectAtOffset(imgWidth/-2, imgHeight/2, Bear.class)!=null||
        getOneObjectAtOffset(imgWidth/2, imgHeight/2, Bear.class)!=null)
        {
          canMoveDown=false;
        }
        return canMoveDown;
    }
     public boolean canMoveUp()
    {
       boolean canMoveUp=true;
        int imgWidth=getImage().getWidth();
        int imgHeight=getImage().getHeight();
     
         if(getOneObjectAtOffset(imgWidth/-2, imgHeight/-2, Bear.class)!=null||
        getOneObjectAtOffset(imgWidth/2, imgHeight/-2, Bear.class)!=null)
        {
          canMoveUp=false;
        }
        return canMoveUp;
    }
    
}
