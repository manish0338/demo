import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
     Counter counter = new Counter();
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }

    public Counter getCounter()
    {
        return counter;
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Ele ele = new Ele();
        addObject(ele,301,145);
        //Bear bear = new Bear();
        //addObject(bear,186,187);
        Bear bear = new Bear();
        addObject(bear,241,206);
      //  Counter counter = new Counter();
        addObject(counter,57,45);
    }
}
